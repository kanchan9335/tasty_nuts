create table User(id integer primary key,
username varchar(255) unique,
password varchar(255),
status varchar(255));

create table Shopdetails(shopId integer primary key,
shopName varchar(255) ,
shopAddress varchar(255));

create table ShopItemDetails(shopId integer references Shopdetails(shopId) ,
shopItems varchar(255),
itemPrice integer);

create table Sequencer(name varchar(255) primary key, value integer);