insert into User values(10000,'SPandit@gmail.com','SPandit@112','Activated');
insert into User values(10001,'SKing@gmail.com','SKing@54','Activated');
insert into Shopdetails values(1,'royal-food','123, kalyani nagar,pune');
insert into Shopdetails values(2,'Punjabi Darbar','124, kalyani nagar,pune');
insert into Shopdetails values(3,'Naturals Ice Cream','125, kalyani nagar,pune');
insert into Shopdetails values(4,'Faasos','126, kalyani nagar,pune');
insert into Shopdetails values(5,'Punjabi Rasoi','127, kalyani nagar,pune');
insert into Shopdetails values(6,'Flavor Of Indian Spices','128, kalyani nagar,pune');
insert into Shopdetails values(7,'Cafe Chocolate','129, kalyani nagar,pune');
insert into Shopdetails values(8,'Shokeens rolls','130, kalyani nagar,pune');

insert into ShopItemDetails values(3,'Chocolate icecream',100.00);
insert into ShopItemDetails values(3,'vanilla icecream',110.00);
insert into ShopItemDetails values(3,'Sitafal icecream',120.00);
insert into ShopItemDetails values(3,'Pista icecream',120.00);
insert into ShopItemDetails values(3,'Dry fruits icecream',120.00);



insert into Sequencer values('user',10003);
insert into Sequencer values('shop',9);
insert into User(id,username,password,status) values (10004,'satyamv@gmail.com','Satyam@12','Activated');
update Sequencer set  value =10004 where name='user';
insert into User(id,username,password,status) values (10005,'Harsha@gmail.com','Mumbai@1212','Activated');update Sequencer set  value =10005 where name='user';