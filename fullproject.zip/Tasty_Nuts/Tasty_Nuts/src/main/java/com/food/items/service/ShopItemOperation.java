package com.food.items.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.food.items.Application;
import com.food.items.dao.IShopItemDetails;
import com.food.items.mapper.ShopItemRowMapper;
import com.food.utils.FileUtils;

public class ShopItemOperation implements IShopItemDetails {

	@Autowired
	JdbcTemplate jdbcTemplate;
	private static ShopItemOperation shp_ops;

	public static ShopItemOperation getInstance() {
		if (shp_ops == null)
		{
			shp_ops = new ShopItemOperation();
		shp_ops.jdbcTemplate = Application.appContext.getBean(JdbcTemplate.class);
		}
		return shp_ops;

	}

	/*
	 * create table ShopItemsDetails(shopId integer references Shopdetails(shopId) ,
	 * shopItems varchar(255), itemPrice integer);
	 */

	@Override
	public List<ShopItemDetails> findItemById(Long id) {
		List<ShopItemDetails> shopItemDetails = jdbcTemplate.query("select * from ShopItemDetails where shopId = ?",
				new Object[] { id }, new ShopItemRowMapper());
		
		return shopItemDetails;
		
	}

	@Override
	public void deleteById(Long id) {

		

	}

	@Override
	public int updateItemDetails(ShopItemDetails details) {
		
		int status = jdbcTemplate.update("update ShopItemDetails set  shopItems =?, itemPrice= ? where shopId=? ",
				new Object[] { details.getShopItems(), details.getItemPrice(),details.getShopId() });
		return status;

	}

	@Override
	public int saveItemDetails(ShopItemDetails details) {
		// TODO Auto-generated method stub
		String sql ="insert into ShopItemDetails(shopId, shopItems, itemPrice) values";
		
		int status = jdbcTemplate.update(sql+"(?,?,?)",
				new Object[] { details.getShopId(), details.getShopItems(), details.getItemPrice() });
		FileUtils.Persistdetails(sql+"('"+details.getShopId()+"','"+details.getShopItems()+"',"+details.getItemPrice()+")");
		return status;
	}


	@Override
	public <S extends ShopItemDetails> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ShopItemDetails> Iterable<S> saveAll(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(Long id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<ShopItemDetails> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<ShopItemDetails> findAllById(Iterable<Long> ids) {
		
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void delete(ShopItemDetails entity) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAll(Iterable<? extends ShopItemDetails> entities) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub

	}

	@Override
	public int deleteItemDetailsById(Long id) {
		int status = jdbcTemplate.update("delete from ShopItemDetails where shopId = ?", new Object[] { id });
		return status;
	}
	
	@Override
	public int deleteItemDetailsByName(Long id, String name) {
		int status = jdbcTemplate.update("delete from ShopItemDetails where shopId = ? and shopItems=?", new Object[] { id, name });
		return status;
	}
	
	public Optional<ShopItemDetails> getItemDetailsByName(Long id, String name) {
		
		ShopItemDetails shopItemDetails = jdbcTemplate.queryForObject("select * from ShopItemDetails where shopId = ? and shopItems=?",
				new Object[] { id ,name}, new BeanPropertyRowMapper<ShopItemDetails>(ShopItemDetails.class));		
		
		return Optional.of(shopItemDetails);
	}
	
	
	
	
	
	@Override
	public Optional<ShopItemDetails> findById(Long arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
