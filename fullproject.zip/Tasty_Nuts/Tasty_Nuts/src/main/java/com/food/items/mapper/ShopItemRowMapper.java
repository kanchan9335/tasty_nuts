package com.food.items.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.food.items.service.ShopItemDetails;

public class ShopItemRowMapper implements RowMapper<ShopItemDetails> {

	@Override
	public ShopItemDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		ShopItemDetails item = new ShopItemDetails();
		item.setShopId(rs.getLong("shopId"));
		item.setShopItems(rs.getString("shopItems"));
		item.setItemPrice(rs.getDouble("itemPrice"));
		return item;
		
	}

}
