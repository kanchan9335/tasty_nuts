package com.food.items.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.food.items.Application;
import com.food.items.dao.IUserDao;
import com.food.utils.FileUtils;

@Repository
@Configuration
public class UserOperations implements IUserDao {
	@Autowired
	JdbcTemplate jdbcTemplate ; 

	private static UserOperations usr_ops;
	
	public UserOperations() {
		
	}
	
	public User getById(long id) {
		User usr = jdbcTemplate.queryForObject("select * from User where id = ?", new Object[] { id },
				new BeanPropertyRowMapper<User>(User.class));
		return usr;
	}
	
	public User getUserbyName(User user) {
		User usr = jdbcTemplate.queryForObject("select * from User where username = ?", new Object[] { user.getUsername() },
				new BeanPropertyRowMapper<User>(User.class));
		return usr;
	}

	public int savedata(User user) {
		String sql="insert into User(id,username,password,status) values ";
		int status = jdbcTemplate.update(sql+"(?,?,?,?)",
				new Object[] { user.getId(), user.getUsername(), user.getPassword(), user.getStatus()});
		FileUtils.Persistdetails(sql+"("+user.getId()+",'"+user.getUsername()+"','"+user.getPassword()+"','Activated');");
		return status;
	}

	public int update(User user) {
		int usr = jdbcTemplate.update("update User set username=?,password=?,status=? where id = ?",
				new Object[] { user.getUsername(), user.getPassword(), user.getStatus(), user.getId() });
		return usr;
	}

	public static UserOperations getInstance() {
		if (usr_ops == null) {
			usr_ops = new UserOperations();
			usr_ops.jdbcTemplate = Application.appContext.getBean(JdbcTemplate.class);
		}
		return usr_ops;

	}
	
	public int deleteUserById(Long id) {
		int count =  jdbcTemplate.update("delete from User where id = ?", new Object[] { id });
	return count;
	}

	@Override
	public <S extends User> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends User> Iterable<S> saveAll(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<User> findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(Long id) {
		
		User usr = jdbcTemplate.queryForObject("select * from User where id = ?", new Object[] { id },
				new BeanPropertyRowMapper<User>(User.class));
		if (usr == null)
			return true;
		else
			return false;
	}

	@Override
	public Iterable<User> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<User> findAllById(Iterable<Long> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public void delete(User entity) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAll(Iterable<? extends User> entities) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		
	}

}
