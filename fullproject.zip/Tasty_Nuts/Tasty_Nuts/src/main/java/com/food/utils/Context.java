package com.food.utils;

public class Context {

	private static String username = null;
	private static String restrauntName =null;
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getRestrauntName() {
		return restrauntName;
	}
	public void setRestrauntName(String restrauntName) {
		this.restrauntName = restrauntName;
	}
	
}
