package com.food.items.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.food.items.service.Sequencer;
import com.food.items.service.SequencerOperations;
import com.food.items.service.User;
import com.food.items.service.UserOperations;

import java.net.*;

@Controller
public class UserController {

	@Autowired
	UserOperations operation;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String First() {
		return ("redirect:login.html");

	}
	 @CrossOrigin(origins = "*")
	@PostMapping("/user/validateUser")
	public ResponseEntity<Object> validateUser(@RequestBody User user) {
		 
		 
		User current_user = operation.getInstance().getUserbyName(user);
		if (current_user != null && user.compare(current_user)) {
			URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/user/{id}")
					.buildAndExpand(user.getId()).toUri();
			return ResponseEntity.created(location).contentType(MediaType.APPLICATION_JSON).body(current_user);
		} else
			return ResponseEntity.badRequest().body("Incorrect Username/Password");
	}

	 @CrossOrigin(origins = "*")
	@GetMapping("/user/{id}")
	public ResponseEntity<Object> getUser(@PathVariable long id) {
		User vs = operation.getInstance().getById(id);
		System.out.println(vs.toString());
		return ResponseEntity.ok(vs);
	}

	 @CrossOrigin(origins = "*")
	@DeleteMapping("/user/{id}")
	public ResponseEntity<Object> removeUser(@PathVariable long id) {
		
		int count =operation.getInstance().deleteUserById(id);
		
		return (count>0)? ResponseEntity.accepted().build() : ResponseEntity.badRequest().body("User Not Exist in Server");
	}

	 @CrossOrigin(origins = "*")
	@PostMapping("/user")
	public ResponseEntity<Object> addUser(@RequestBody User user) {
		 long sequence = SequencerOperations.getInstance().findbyName("user");
		 user.setId(sequence+1);
		int count = operation.getInstance().savedata(user);
		if (count>0) {
			Sequencer s = new Sequencer();
			s.setName("user");
			s.setValue(sequence+1);
			SequencerOperations.getInstance().updateItemDetails(s);
			URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
					.buildAndExpand(user.getId()).toUri();
			return ResponseEntity.created(location).body(user);
		} else
			return ResponseEntity.badRequest().build();
	}

	 @CrossOrigin(origins = "*")
	@PutMapping("/user/details")
	public ResponseEntity<Object> getUserDetails(@RequestBody User user) {

		User usr = operation.getInstance().getUserbyName(user);
		
		return (usr == null)? ResponseEntity.notFound().build():ResponseEntity.ok().body(usr);
	}
	 
	 @CrossOrigin(origins = "*")
	@PutMapping("/user/update")
	public ResponseEntity<Object> updateUser(@RequestBody User user) {

		int status = operation.getInstance().update(user);
		
		return (status >=0)? ResponseEntity.ok(" User details Updated Successfully"):ResponseEntity.badRequest().build();
	}
}
