package com.food.utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileUtils {
	
	public static void Persistdetails(String query) {
		String filename=System.getProperty("user.dir")+"/src/main/resources/data.sql";
		FileUtils.appendStrToFile(filename, query);
	}

	public static void appendStrToFile(String fileName, String str) 
{ 
		try { 

			// Open given file in append mode. 
			BufferedWriter out = new BufferedWriter( 
					new FileWriter(fileName, true)); 
			out.write(str); 
			out.close(); 
		} 
		catch (IOException e) { 
			System.out.println("exception occoured" + e); 

		}
}

}