package com.food.items.dao;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.food.items.service.ShopItemDetails;

public interface IShopItemDetails extends CrudRepository<ShopItemDetails, Long> {
	public int updateItemDetails(ShopItemDetails details);
	public int saveItemDetails(ShopItemDetails details);
	public int deleteItemDetailsById(Long id);
	List<ShopItemDetails> findItemById(Long id);
	int deleteItemDetailsByName(Long id, String name);
}
