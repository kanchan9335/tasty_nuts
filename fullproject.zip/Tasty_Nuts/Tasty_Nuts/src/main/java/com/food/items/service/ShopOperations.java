package com.food.items.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.food.items.Application;
import com.food.items.dao.IShopDetails;

public class ShopOperations implements IShopDetails {

	@Autowired
	JdbcTemplate jdbcTemplate;
	private static ShopOperations shp_ops;

	public static ShopOperations getInstance() {
		if (shp_ops == null){
			shp_ops = new ShopOperations();
			shp_ops.jdbcTemplate = Application.appContext.getBean(JdbcTemplate.class);
		}
		return shp_ops;

	}

	@Override
	public int update(Shopdetails details) {
		// TODO Auto-generated method stub
		int status = jdbcTemplate.update("update Shopdetails  set shopName =?,shopAddress=? where shopId=?",
				new Object[] {  details.getShopName(), details.getShopAddress(),details.getShopId() });
		return status;
	}

	@Override
	public int saveDetails(Shopdetails details) {
		// TODO Auto-generated method stub
		int status = jdbcTemplate.update("insert into Shopdetails(shopId,shopName,shopAddress) values (?,?,?)",
				new Object[] { details.getShopId(), details.getShopName(), details.getShopAddress() });
		return status;

	}

	@Override
	public <S extends Shopdetails> S save(S entity) {

		return null;
	}

	@Override
	public void deleteById(Long id) {

	}

	@Override
	public <S extends Shopdetails> Iterable<S> saveAll(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Shopdetails> findById(Long id) {
		Shopdetails shopDetails = jdbcTemplate.queryForObject("select * from Shopdetails where shopId = ?",
				new Object[] { id }, new BeanPropertyRowMapper<Shopdetails>(Shopdetails.class));
		return Optional.of(shopDetails);

	}
	
	@Override
	public Optional<Shopdetails> findByName(String name) {
		Shopdetails shopDetails = jdbcTemplate.queryForObject("select * from Shopdetails where shopName = ?",
				new Object[] { name }, new BeanPropertyRowMapper<Shopdetails>(Shopdetails.class));
		return Optional.of(shopDetails);

	}

	@Override
	public boolean existsById(Long id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<Shopdetails> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<Shopdetails> findAllById(Iterable<Long> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void delete(Shopdetails entity) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAll(Iterable<? extends Shopdetails> entities) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub

	}

	@Override
	public int deleteShopDetailsById(Long id) {
		int status = jdbcTemplate.update("delete from Shopdetails where shopId = ?", new Object[] { id });
		return status;
	}

}
