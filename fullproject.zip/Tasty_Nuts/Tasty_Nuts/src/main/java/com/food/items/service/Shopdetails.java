package com.food.items.service;

import javax.persistence.Entity;

@Entity
public class Shopdetails {
	private Long shopId;
	
	private String shopName;
	private String shopAddress;
	
	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopAddress() {
		return shopAddress;
	}

	public void setShopAddress(String shopAddress) {
		this.shopAddress = shopAddress;
	}

	
	public Long getShopId() {
		return shopId;
	}

	public void setShopId(Long shopId) {
		this.shopId = shopId;
	}

	@Override
	public String toString() {
		return "Shopdetails [shopName=" + shopName + ", shopAddress=" + shopAddress + "]";
	}
}
