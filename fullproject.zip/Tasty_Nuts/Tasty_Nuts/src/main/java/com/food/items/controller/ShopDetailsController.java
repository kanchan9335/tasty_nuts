package com.food.items.controller;

import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.food.items.service.Sequencer;
import com.food.items.service.SequencerOperations;
import com.food.items.service.ShopOperations;
import com.food.items.service.Shopdetails;


@RestController
@Controller
public class ShopDetailsController {
	@CrossOrigin(origins = "*")
	@GetMapping("/shop/{id}")
	public ResponseEntity<Object> getShopDetail(@PathVariable Long id) {
		 Optional<Shopdetails> shopdetail = ShopOperations.getInstance().findById(id);
		 
		return ResponseEntity.ok(shopdetail.get());
	}
	@CrossOrigin(origins = "*")
	@GetMapping("/shop/name/{name}")
	public ResponseEntity<Object> getShopDetailByName(@PathVariable String name) {
		 Optional<Shopdetails> shopdetail = ShopOperations.getInstance().findByName(URLDecoder.decode(name));
		 
		return ResponseEntity.ok(shopdetail.get());
	}
	
	
	@CrossOrigin(origins = "*")
	@DeleteMapping("/shop/{id}")
	public ResponseEntity<Object> removeShopDetail(@PathVariable Long id) {
		int status = ShopOperations.getInstance().deleteShopDetailsById(id);
		return (status>0)? ResponseEntity.accepted().build() : ResponseEntity.badRequest().body("Shop Details Not Exist in Server");
	}
	@CrossOrigin(origins = "*")
	@PostMapping("/shop")
	public ResponseEntity<Object> addShopDetail(@RequestBody Shopdetails details) {
		long sequence = SequencerOperations.getInstance().findbyName("shop");
		int status = ShopOperations.getInstance().saveDetails(details);
		details.setShopId(sequence+1);
		if (status >0) {
			Sequencer s = new Sequencer();
			s.setName("shop");
			s.setValue(sequence+1);
			SequencerOperations.getInstance().updateItemDetails(s);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(details.getShopId())
				.toUri();
		return ResponseEntity.created(location).body(details);
		}
		else {
			return ResponseEntity.badRequest().build();
		}
	}
	@CrossOrigin(origins = "*")
	@PutMapping("/shop/update")
	public ResponseEntity<Object> updateShopDetail(@RequestBody Shopdetails details) {

		int status = ShopOperations.getInstance().update(details);
		return (status >=0)? ResponseEntity.ok(" Shop details Updated Successfully"):ResponseEntity.badRequest().build();
	}
}

