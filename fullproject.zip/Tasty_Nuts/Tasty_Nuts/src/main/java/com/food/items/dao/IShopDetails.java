package com.food.items.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.food.items.service.Shopdetails;

public interface IShopDetails extends CrudRepository<Shopdetails, Long> {
public int update(Shopdetails details);
public int saveDetails(Shopdetails details);
public int deleteShopDetailsById(Long id);
public Optional<Shopdetails> findByName(String name);
}
