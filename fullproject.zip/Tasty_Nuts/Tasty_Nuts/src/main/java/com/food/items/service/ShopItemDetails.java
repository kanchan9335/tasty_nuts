package com.food.items.service;

public class ShopItemDetails {

	private Long ShopId;
	private  String shopItems;
	private double itemPrice;
	
	public Long getShopId() {
		return ShopId;
	}
	public void setShopId(Long shopId) {
		ShopId = shopId;
	}
	public String getShopItems() {
		return shopItems;
	}
	public void setShopItems(String shopItems) {
		this.shopItems = shopItems;
	}
	public double getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}

	@Override
	public String toString() {
		return "ShopItemDetails [ShopId=" + ShopId + ", shopItems=" + shopItems + ", itemPrice=" + itemPrice + "]";
	}
}
