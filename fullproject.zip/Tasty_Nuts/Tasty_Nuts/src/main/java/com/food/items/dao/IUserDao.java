package com.food.items.dao;

import org.springframework.data.repository.CrudRepository;

import com.food.items.service.User;

public interface IUserDao extends CrudRepository<User, Long> {
	public User getById(long id);

	public int savedata(User employee);
	public int deleteUserById(Long id);
	public int update(User employee);
}
