package com.food.items.controller;

import java.net.URI;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.food.items.service.Sequencer;
import com.food.items.service.SequencerOperations;
import com.food.items.service.ShopOperations;
import com.food.items.service.Shopdetails;
import com.food.utils.Context;

@RestController
@Controller
public class ContextHandler {

	Context context = new Context();
		@CrossOrigin(origins = "*")
		@GetMapping("/context/username")
		public ResponseEntity<Object> getUsername() {
			if(context.getUsername() != null && context.getUsername() != "" ){
			return ResponseEntity.ok(context.getUsername());
			}
			else{
				return ResponseEntity.badRequest().build();
			}
		}
		
		@CrossOrigin(origins = "*")
		@GetMapping("/ShopName/ShopName")
		public ResponseEntity<Object> getShopName() {

			if(context.getRestrauntName() != null && context.getRestrauntName() != "" ){
				return ResponseEntity.ok(context.getRestrauntName());
				}
				else{
					return ResponseEntity.badRequest().build();
				}
			
		}

		@CrossOrigin(origins = "*")
		@PostMapping("/context/{username}")
		public ResponseEntity<Object> setUsername(@PathVariable String username) {
				context.setUsername(username);
				return ResponseEntity.ok().build();
		}
		
		@CrossOrigin(origins = "*")
		@PostMapping("/ShopName/{shopName}")
		public ResponseEntity<Object> setShopName(@PathVariable String shopName) {
			context.setRestrauntName(shopName);
			return ResponseEntity.ok().build();
		}

		}


