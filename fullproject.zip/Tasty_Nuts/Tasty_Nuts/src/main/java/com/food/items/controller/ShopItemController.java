package com.food.items.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.food.items.service.ShopItemDetails;
import com.food.items.service.ShopItemOperation;
import com.food.items.service.ShopOperations;
import com.food.items.service.Shopdetails;

import java.net.*;
import java.util.List;
import java.util.Optional;

@RestController
@Controller
public class ShopItemController {
	
	@CrossOrigin(origins = "*")
	@GetMapping("/item/{id}")
	public ResponseEntity<Object> getItemDetail(@PathVariable Long id) {
		 List<ShopItemDetails> itemdetail = ShopItemOperation.getInstance().findItemById(id);
		 
		return ResponseEntity.ok(itemdetail);
	}
	
	@CrossOrigin(origins = "*")
	@GetMapping("/item/{id}/{shopItems}")
	public ResponseEntity<Object> getItemDetail(@PathVariable Long id, @PathVariable String shopItems) {
		 Optional<ShopItemDetails> itemdetail = ShopItemOperation.getInstance().getItemDetailsByName(id,shopItems);
		 
		return ResponseEntity.ok(Optional.of(itemdetail));
	}
	
	
	
	
	@CrossOrigin(origins = "*")
	@DeleteMapping("/item/{id}")
	public ResponseEntity<Object> removeItemDetail(@PathVariable Long id) {
		int count = ShopItemOperation.getInstance().deleteItemDetailsById(id);
		return (count>0)? ResponseEntity.accepted().build() : ResponseEntity.badRequest().body("Item Not Exist in Server");
	}
	@CrossOrigin(origins = "*")
	@DeleteMapping("/item/{id}/{shopItems}")
	public ResponseEntity<Object> removeItemDetail(@PathVariable Long id, @PathVariable String shopItems) {
		int count = ShopItemOperation.getInstance().deleteItemDetailsByName(id,shopItems);
		return (count>0)? ResponseEntity.accepted().build() : ResponseEntity.badRequest().body("Item Not Exist in Server");
	}
	
	@CrossOrigin(origins = "*")
	@PostMapping("/item")
	public ResponseEntity<Object> addItemDetail(@RequestBody ShopItemDetails details) {
		int status = ShopItemOperation.getInstance().saveItemDetails(details);
		
		if (status >0) {
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(details.getShopId())
				.toUri();
		return ResponseEntity.created(location).body(details);
		}
		else {
			return ResponseEntity.badRequest().build();
		}
	}

	@CrossOrigin(origins = "*")
	@PutMapping("/item/update")
	public ResponseEntity<Object> updateItemDetail(@RequestBody ShopItemDetails details) {

		int status = ShopItemOperation.getInstance().updateItemDetails(details);
		return (status >=0)? ResponseEntity.ok(" Item details Updated Successfully"):ResponseEntity.badRequest().build();
	}
}
