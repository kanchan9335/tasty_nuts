package com.food.items.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.food.items.Application;
import com.food.items.mapper.ShopItemRowMapper;
import com.food.utils.FileUtils;

public class SequencerOperations {

	@Autowired
	JdbcTemplate jdbcTemplate;
	private static SequencerOperations sq_ops;

	public static SequencerOperations getInstance() {
		if (sq_ops == null)
		{
			sq_ops = new SequencerOperations();
			sq_ops.jdbcTemplate = Application.appContext.getBean(JdbcTemplate.class);
		}
		return sq_ops;

	}
	

	public long findbyName(String name) {
		   Sequencer s = jdbcTemplate.queryForObject("select * from Sequencer where name = ?",
				new Object[] { name }, new BeanPropertyRowMapper<Sequencer>(Sequencer.class) );
		
		return s.getValue();
		
	}
	
	public int updateItemDetails(Sequencer seq) {
		
		int status = jdbcTemplate.update("update Sequencer set  value =? where name=? ",
				new Object[] { seq.getValue(),seq.getName() });
		FileUtils.Persistdetails("update Sequencer set  value ="+seq.getValue()+" where name='"+seq.getName()+"';");
		return status;

	}

	
}
